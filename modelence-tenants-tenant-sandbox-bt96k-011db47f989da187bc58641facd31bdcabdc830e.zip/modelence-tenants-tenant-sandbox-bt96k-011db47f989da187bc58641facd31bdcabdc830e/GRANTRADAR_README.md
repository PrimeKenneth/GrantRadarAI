# GrantRadar AI - SaaS Grant Discovery Platform

A premium, full-stack SaaS application built with Modelence for discovering and tracking grant opportunities with intelligent deadline management.

## Features

### Core Functionality
- **Opportunity Discovery**: Browse and search through grant opportunities with advanced filtering
- **Smart Deadline Tracking**: Automated urgency detection (Safe, Approaching, Closing Soon)
- **Personal Dashboard**: Track your saved opportunities and applications
- **Admin Panel**: Complete CRUD interface for managing opportunities
- **Authentication**: Secure user registration and login with Modelence Auth

### User Features
- Save opportunities for later review
- Apply to opportunities with one click
- Filter by category, region, urgency, and reward amount
- Real-time search functionality
- Dashboard with statistics and insights
- Visual urgency indicators with countdown timers

### Admin Features
- Add new grant opportunities
- Edit existing opportunities
- Delete opportunities
- Table-based management interface
- Form validation and error handling

## Tech Stack

### Frontend
- **React 18** with TypeScript
- **React Router** for navigation
- **TanStack Query** for state management
- **Tailwind CSS** for styling
- **Lucide Icons** for iconography
- **React Hot Toast** for notifications

### Backend
- **Modelence Framework** (Node.js/TypeScript)
- **MongoDB** for data storage
- **Zod** for validation
- **Cron Jobs** for automated urgency updates

## Project Structure

```
src/
├── client/                        # React frontend
│   ├── components/
│   │   ├── ui/                   # Reusable UI components
│   │   │   ├── Badge.tsx
│   │   │   ├── Button.tsx
│   │   │   ├── Card.tsx
│   │   │   ├── Dialog.tsx
│   │   │   ├── Input.tsx
│   │   │   └── Label.tsx
│   │   ├── OpportunityCard.tsx   # Opportunity display card
│   │   └── Sidebar.tsx           # Navigation sidebar
│   ├── pages/
│   │   ├── HomePage.tsx          # Landing page
│   │   ├── DashboardPage.tsx     # User dashboard with stats
│   │   ├── ExplorePage.tsx       # Browse opportunities
│   │   ├── SavedPage.tsx         # Saved opportunities
│   │   ├── AppliedPage.tsx       # Applied opportunities
│   │   ├── AdminPage.tsx         # Admin CRUD panel
│   │   ├── LoginPage.tsx         # User login
│   │   └── SignupPage.tsx        # User registration
│   └── router.tsx                # Route configuration
│
└── server/                        # Node.js backend
    ├── grantradar/
    │   ├── index.ts              # Main module with queries/mutations
    │   ├── db.ts                 # Database schemas
    │   └── cron.ts               # Scheduled urgency updates
    ├── migrations/
    │   └── createSampleOpportunities.ts
    └── app.ts                    # Server entry point
```

## Database Schema

### Opportunities
- Title, description, category, region
- Reward amount and deadline
- Urgency status (auto-calculated)
- Optional image and application URLs
- Timestamps for creation and updates

### Saved Opportunities
- User-opportunity relationship
- Saved timestamp

### Applied Opportunities
- User-opportunity relationship
- Application timestamp
- Application status

## API Endpoints (Queries & Mutations)

### Queries
- `getOpportunities` - Get all opportunities with optional filters
- `getOpportunity` - Get single opportunity by ID
- `getSavedOpportunities` - Get user's saved opportunities
- `getAppliedOpportunities` - Get user's applications
- `getDashboardStats` - Get user statistics
- `getOpportunityStatus` - Check if user saved/applied to opportunity
- `getCategories` - Get all unique categories
- `getRegions` - Get all unique regions

### Mutations
- `saveOpportunity` - Save an opportunity
- `unsaveOpportunity` - Remove saved opportunity
- `applyToOpportunity` - Apply to an opportunity
- `createOpportunity` - Admin: Create new opportunity
- `updateOpportunity` - Admin: Update opportunity
- `deleteOpportunity` - Admin: Delete opportunity

## Background Jobs

### Urgency Update Cron
Runs every hour to automatically update deadline urgency status:
- **Safe**: More than 7 days remaining
- **Approaching**: 4-7 days remaining
- **Closing Soon**: 3 days or less remaining

## Getting Started

### Prerequisites
- Node.js 18+ and npm
- Modelence Cloud account (database already configured)

### Installation
The app is already set up and running. The server is running on port 3000 with hot reload enabled.

### Demo User
```
Email: demo@modelence.dev
Password: 12345678
```

### Sample Data
Sample opportunities are automatically created on first run via migrations.

## Key Routes

- `/` - Landing page
- `/login` - User login
- `/signup` - User registration
- `/dashboard` - User dashboard (protected)
- `/explore` - Browse opportunities (protected)
- `/saved` - Saved opportunities (protected)
- `/applied` - Applied opportunities (protected)
- `/admin` - Admin panel (protected)

## Design System

### Colors
- **Primary**: Deep indigo/purple gradients
- **Secondary**: Soft blue
- **Accent**: Cyan/neon green
- **Neutral**: White, light gray, dark slate

### Typography
- Modern sans-serif font family
- Bold headings for emphasis
- Clean, readable body text

### Components
- Glassmorphism card effects
- Smooth hover animations
- Soft shadows and rounded corners
- High contrast for accessibility
- Mobile responsive design

## Development

### TypeScript
Run type checking:
```bash
npx tsc --noEmit
```

### Build
```bash
npm run build
```

### Production
```bash
npm start
```

## Features in Detail

### Opportunity Card
Each opportunity displays:
- Category and region badges
- Reward amount highlighted
- Countdown timer with time remaining
- Color-coded urgency indicator
- Save and Apply action buttons
- Optional opportunity image

### Filtering System
Advanced filters include:
- Category dropdown
- Region dropdown
- Urgency level selector
- Min/max reward range
- Search by title or description
- Active filter count indicator

### Dashboard Statistics
- Number of saved opportunities
- Number of applications submitted
- Total potential reward value
- Upcoming deadlines (within 7 days)

## Security

- All user routes are protected with authentication
- User IDs are validated on all operations
- Queries and mutations use Zod schema validation
- MongoDB ObjectId validation prevents injection

## Performance

- Lazy-loaded routes with React Suspense
- Optimized MongoDB indexes on frequently queried fields
- React Query for efficient data caching
- Debounced search input

## Future Enhancements

Potential features for future versions:
- User roles and permissions (admin vs regular user)
- Email notifications for approaching deadlines
- Advanced search with multiple criteria
- Opportunity recommendations based on user interests
- Export saved opportunities to CSV
- Application status tracking workflow
- Comments and notes on saved opportunities
- Calendar integration for deadlines

## Support

For issues or questions:
- Email: support@modelence.com
- Documentation: https://docs.modelence.com

---

Built with Modelence - The all-in-one TypeScript framework for full-stack apps.
