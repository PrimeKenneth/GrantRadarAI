import React, { useMemo } from 'react';
import { Card, CardContent, CardFooter } from '@/client/components/ui/Card';
import { Badge } from '@/client/components/ui/Badge';
import { Button } from '@/client/components/ui/Button';
import { Bookmark, ExternalLink, Clock } from 'lucide-react';
import { cn } from '@/client/lib/utils';

interface OpportunityCardProps {
  title: string;
  description: string;
  category: string;
  region: string;
  reward: number;
  deadline: Date;
  urgency: string;
  imageUrl?: string;
  isSaved?: boolean;
  isApplied?: boolean;
  onSave?: () => void;
  onApply?: () => void;
}

export const OpportunityCard: React.FC<OpportunityCardProps> = ({
  title,
  description,
  category,
  region,
  reward,
  deadline,
  urgency,
  imageUrl,
  isSaved = false,
  isApplied = false,
  onSave,
  onApply,
}) => {
  const { timeRemaining } = useMemo(() => {
    const now = new Date();
    const deadlineDate = new Date(deadline);
    const diff = deadlineDate.getTime() - now.getTime();
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24));

    if (days < 0) {
      return { timeRemaining: 'Expired', daysLeft: 0 };
    } else if (days === 0) {
      return { timeRemaining: 'Today', daysLeft: 0 };
    } else if (days === 1) {
      return { timeRemaining: '1 day left', daysLeft: 1 };
    } else if (days < 7) {
      return { timeRemaining: `${days} days left`, daysLeft: days };
    } else {
      const weeks = Math.floor(days / 7);
      return { timeRemaining: `${weeks} week${weeks > 1 ? 's' : ''} left`, daysLeft: days };
    }
  }, [deadline]);

  const urgencyVariant = useMemo(() => {
    if (urgency === 'closing-soon') return 'destructive';
    if (urgency === 'approaching') return 'warning';
    return 'success';
  }, [urgency]);

  const urgencyLabel = useMemo(() => {
    if (urgency === 'closing-soon') return 'Closing Soon';
    if (urgency === 'approaching') return 'Approaching';
    return 'Safe';
  }, [urgency]);

  return (
    <Card className="group relative overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1 bg-white/80 backdrop-blur-sm border border-gray-200">
      {imageUrl && (
        <div className="h-48 overflow-hidden bg-gradient-to-br from-indigo-50 to-purple-50">
          <img
            src={imageUrl}
            alt={title}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
        </div>
      )}

      <CardContent className="p-6 space-y-4">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1">
            <h3 className="text-xl font-bold text-gray-900 line-clamp-2 mb-2">{title}</h3>
            <div className="flex flex-wrap gap-2 mb-3">
              <Badge variant="secondary" className="text-xs">
                {category}
              </Badge>
              <Badge variant="outline" className="text-xs">
                {region}
              </Badge>
            </div>
          </div>
        </div>

        <p className="text-sm text-gray-600 line-clamp-3">{description}</p>

        <div className="flex items-center justify-between pt-3 border-t border-gray-100">
          <div>
            <p className="text-2xl font-bold text-indigo-600">
              ${reward.toLocaleString()}
            </p>
            <p className="text-xs text-gray-500">Reward</p>
          </div>

          <div className="text-right">
            <div className="flex items-center gap-1 text-sm font-semibold mb-1">
              <Clock className="w-4 h-4" />
              <span>{timeRemaining}</span>
            </div>
            <Badge variant={urgencyVariant} className="text-xs">
              {urgencyLabel}
            </Badge>
          </div>
        </div>
      </CardContent>

      <CardFooter className="p-4 pt-0 flex gap-2">
        <Button
          variant={isSaved ? 'default' : 'outline'}
          size="sm"
          onClick={onSave}
          className={cn(
            'flex-1 transition-all',
            isSaved && 'bg-indigo-600 hover:bg-indigo-700'
          )}
        >
          <Bookmark className={cn('w-4 h-4 mr-2', isSaved && 'fill-current')} />
          {isSaved ? 'Saved' : 'Save'}
        </Button>

        <Button
          variant={isApplied ? 'secondary' : 'default'}
          size="sm"
          onClick={onApply}
          disabled={isApplied}
          className={cn(
            'flex-1 transition-all',
            !isApplied && 'bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700'
          )}
        >
          <ExternalLink className="w-4 h-4 mr-2" />
          {isApplied ? 'Applied' : 'Apply'}
        </Button>
      </CardFooter>
    </Card>
  );
};
