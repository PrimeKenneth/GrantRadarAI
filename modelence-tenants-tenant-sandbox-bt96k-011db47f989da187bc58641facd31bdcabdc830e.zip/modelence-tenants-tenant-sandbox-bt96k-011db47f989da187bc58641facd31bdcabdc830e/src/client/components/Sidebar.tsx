import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/client/lib/utils';
import { Home, Compass, Bookmark, CheckCircle, Settings } from 'lucide-react';

interface SidebarProps {
  className?: string;
}

const navItems = [
  { name: 'Dashboard', path: '/dashboard', icon: Home },
  { name: 'Explore', path: '/explore', icon: Compass },
  { name: 'Saved', path: '/saved', icon: Bookmark },
  { name: 'Applied', path: '/applied', icon: CheckCircle },
  { name: 'Admin Panel', path: '/admin', icon: Settings },
];

export const Sidebar: React.FC<SidebarProps> = ({ className }) => {
  const location = useLocation();

  return (
    <aside
      className={cn(
        'w-64 h-screen bg-gradient-to-b from-indigo-900 to-purple-900 text-white fixed left-0 top-0 flex flex-col',
        className
      )}
    >
      <div className="p-6 border-b border-white/10">
        <Link to="/" className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-400 to-indigo-400 flex items-center justify-center font-bold text-lg">
            GR
          </div>
          <div>
            <h1 className="text-xl font-bold">GrantRadar AI</h1>
            <p className="text-xs text-indigo-200">Find Opportunities</p>
          </div>
        </Link>
      </div>

      <nav className="flex-1 px-4 py-6 space-y-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;

          return (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                'flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200',
                isActive
                  ? 'bg-white/20 text-white shadow-lg'
                  : 'text-indigo-200 hover:bg-white/10 hover:text-white'
              )}
            >
              <Icon className="w-5 h-5" />
              <span className="font-medium">{item.name}</span>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-white/10">
        <Link
          to="/logout"
          className="flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 transition-all text-sm"
        >
          Logout
        </Link>
      </div>
    </aside>
  );
};
