import React, { useState, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { modelenceQuery, modelenceMutation, createQueryKey } from '@modelence/react-query';
import { Sidebar } from '@/client/components/Sidebar';
import { Button } from '@/client/components/ui/Button';
import { Input } from '@/client/components/ui/Input';
import { Label } from '@/client/components/ui/Label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/client/components/ui/Dialog';
import { Badge } from '@/client/components/ui/Badge';
import { Plus, Edit, Trash2 } from 'lucide-react';
import LoadingSpinner from '@/client/components/LoadingSpinner';
import toast from 'react-hot-toast';

interface Opportunity {
  _id: string;
  title: string;
  description: string;
  category: string;
  region: string;
  reward: number;
  deadline: Date;
  urgency: string;
  imageUrl?: string;
  applicationUrl?: string;
}

interface OpportunityForm {
  title: string;
  description: string;
  category: string;
  region: string;
  reward: string;
  deadline: string;
  imageUrl: string;
  applicationUrl: string;
}

const emptyForm: OpportunityForm = {
  title: '',
  description: '',
  category: '',
  region: '',
  reward: '',
  deadline: '',
  imageUrl: '',
  applicationUrl: '',
};

export default function AdminPage() {
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<OpportunityForm>(emptyForm);

  const { data: opportunities, isLoading } = useQuery({
    ...modelenceQuery<Opportunity[]>('grantradar.getOpportunities', {}),
  });

  const { mutate: createOpportunity, isPending: isCreating } = useMutation({
    ...modelenceMutation('grantradar.createOpportunity'),
    onSuccess: () => {
      toast.success('Opportunity created successfully');
      queryClient.invalidateQueries({ queryKey: createQueryKey('grantradar.getOpportunities', {}) });
      setIsDialogOpen(false);
      setFormData(emptyForm);
    },
    onError: (error: Error) => {
      toast.error(error.message);
    },
  });

  const { mutate: updateOpportunity, isPending: isUpdating } = useMutation({
    ...modelenceMutation('grantradar.updateOpportunity'),
    onSuccess: () => {
      toast.success('Opportunity updated successfully');
      queryClient.invalidateQueries({ queryKey: createQueryKey('grantradar.getOpportunities', {}) });
      setIsDialogOpen(false);
      setFormData(emptyForm);
      setEditingId(null);
    },
    onError: (error: Error) => {
      toast.error(error.message);
    },
  });

  const { mutate: deleteOpportunity } = useMutation({
    ...modelenceMutation('grantradar.deleteOpportunity'),
    onSuccess: () => {
      toast.success('Opportunity deleted successfully');
      queryClient.invalidateQueries({ queryKey: createQueryKey('grantradar.getOpportunities', {}) });
    },
    onError: (error: Error) => {
      toast.error(error.message);
    },
  });

  const handleOpenCreate = useCallback(() => {
    setEditingId(null);
    setFormData(emptyForm);
    setIsDialogOpen(true);
  }, []);

  const handleOpenEdit = useCallback((opportunity: Opportunity) => {
    setEditingId(opportunity._id);
    setFormData({
      title: opportunity.title,
      description: opportunity.description,
      category: opportunity.category,
      region: opportunity.region,
      reward: opportunity.reward.toString(),
      deadline: new Date(opportunity.deadline).toISOString().split('T')[0],
      imageUrl: opportunity.imageUrl || '',
      applicationUrl: opportunity.applicationUrl || '',
    });
    setIsDialogOpen(true);
  }, []);

  const handleSubmit = useCallback(
    (e: React.FormEvent) => {
      e.preventDefault();

      const data = {
        title: formData.title,
        description: formData.description,
        category: formData.category,
        region: formData.region,
        reward: Number(formData.reward),
        deadline: formData.deadline,
        imageUrl: formData.imageUrl || undefined,
        applicationUrl: formData.applicationUrl || undefined,
      };

      if (editingId) {
        updateOpportunity({ id: editingId, ...data });
      } else {
        createOpportunity(data);
      }
    },
    [formData, editingId, createOpportunity, updateOpportunity]
  );

  const handleDelete = useCallback(
    (id: string) => {
      if (confirm('Are you sure you want to delete this opportunity?')) {
        deleteOpportunity({ id });
      }
    },
    [deleteOpportunity]
  );

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />

      <main className="flex-1 ml-64">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Admin Panel</h1>
            <Button
              onClick={handleOpenCreate}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Opportunity
            </Button>
          </div>

          {isLoading ? (
            <div className="flex justify-center items-center py-20">
              <LoadingSpinner />
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow overflow-hidden">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Title
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Category
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Region
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Reward
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Deadline
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Urgency
                    </th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {opportunities?.map((opportunity) => (
                    <tr key={opportunity._id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">{opportunity.title}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Badge variant="secondary">{opportunity.category}</Badge>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {opportunity.region}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ${opportunity.reward.toLocaleString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {new Date(opportunity.deadline).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Badge
                          variant={
                            opportunity.urgency === 'closing-soon'
                              ? 'destructive'
                              : opportunity.urgency === 'approaching'
                              ? 'warning'
                              : 'success'
                          }
                        >
                          {opportunity.urgency}
                        </Badge>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button
                          onClick={() => handleOpenEdit(opportunity)}
                          className="text-indigo-600 hover:text-indigo-900 mr-4"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(opportunity._id)}
                          className="text-red-600 hover:text-red-900"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingId ? 'Edit Opportunity' : 'Create New Opportunity'}</DialogTitle>
              </DialogHeader>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="title">Title *</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="description">Description *</Label>
                  <textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    required
                    rows={4}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="category">Category *</Label>
                    <Input
                      id="category"
                      value={formData.category}
                      onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="region">Region *</Label>
                    <Input
                      id="region"
                      value={formData.region}
                      onChange={(e) => setFormData({ ...formData, region: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="reward">Reward ($) *</Label>
                    <Input
                      id="reward"
                      type="number"
                      value={formData.reward}
                      onChange={(e) => setFormData({ ...formData, reward: e.target.value })}
                      required
                      min="0"
                    />
                  </div>

                  <div>
                    <Label htmlFor="deadline">Deadline *</Label>
                    <Input
                      id="deadline"
                      type="date"
                      value={formData.deadline}
                      onChange={(e) => setFormData({ ...formData, deadline: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="imageUrl">Image URL</Label>
                  <Input
                    id="imageUrl"
                    type="url"
                    value={formData.imageUrl}
                    onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
                    placeholder="https://example.com/image.jpg"
                  />
                </div>

                <div>
                  <Label htmlFor="applicationUrl">Application URL</Label>
                  <Input
                    id="applicationUrl"
                    type="url"
                    value={formData.applicationUrl}
                    onChange={(e) => setFormData({ ...formData, applicationUrl: e.target.value })}
                    placeholder="https://example.com/apply"
                  />
                </div>

                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={isCreating || isUpdating}
                    className="bg-indigo-600 hover:bg-indigo-700"
                  >
                    {isCreating || isUpdating ? 'Saving...' : editingId ? 'Update' : 'Create'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </main>
    </div>
  );
}
