import { Link } from 'react-router-dom';
import { Button } from '@/client/components/ui/Button';
import { Card, CardContent } from '@/client/components/ui/Card';
import { Sparkles, Target, Clock, TrendingUp } from 'lucide-react';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      <header className="border-b border-gray-200 bg-white/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center font-bold text-white">
              GR
            </div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              GrantRadar AI
            </h1>
          </div>
          <div className="flex gap-3">
            <Link to="/login">
              <Button variant="ghost">Login</Button>
            </Link>
            <Link to="/signup">
              <Button className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700">
                Get Started
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main>
        <section className="max-w-7xl mx-auto px-6 py-24 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-indigo-100 text-indigo-700 text-sm font-medium mb-8">
            <Sparkles className="w-4 h-4" />
            AI-Powered Opportunity Discovery
          </div>

          <h1 className="text-6xl font-bold text-gray-900 mb-6 leading-tight">
            Discover Grant Opportunities
            <br />
            <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              Before They Close
            </span>
          </h1>

          <p className="text-xl text-gray-600 mb-12 max-w-3xl mx-auto leading-relaxed">
            GrantRadar AI helps you find, track, and apply to funding opportunities with intelligent
            deadline tracking and personalized recommendations.
          </p>

          <div className="flex gap-4 justify-center mb-16">
            <Link to="/signup">
              <Button
                size="lg"
                className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-lg px-8 py-6"
              >
                Get Started
              </Button>
            </Link>
            <Link to="/explore">
              <Button size="lg" variant="outline" className="text-lg px-8 py-6">
                Explore Opportunities
              </Button>
            </Link>
          </div>

          <div className="grid md:grid-cols-4 gap-6 max-w-5xl mx-auto">
            <Card className="border-2 border-transparent hover:border-indigo-200 transition-all">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-indigo-100 to-purple-100 flex items-center justify-center mx-auto mb-4">
                  <Target className="w-6 h-6 text-indigo-600" />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">Smart Matching</h3>
                <p className="text-sm text-gray-600">
                  AI-powered recommendations tailored to your profile
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 border-transparent hover:border-indigo-200 transition-all">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-purple-100 to-pink-100 flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-6 h-6 text-purple-600" />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">Deadline Alerts</h3>
                <p className="text-sm text-gray-600">
                  Never miss an opportunity with smart notifications
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 border-transparent hover:border-indigo-200 transition-all">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-cyan-100 to-blue-100 flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="w-6 h-6 text-cyan-600" />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">Track Progress</h3>
                <p className="text-sm text-gray-600">
                  Monitor your applications in one dashboard
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 border-transparent hover:border-indigo-200 transition-all">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-green-100 to-emerald-100 flex items-center justify-center mx-auto mb-4">
                  <Sparkles className="w-6 h-6 text-green-600" />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">Premium Insights</h3>
                <p className="text-sm text-gray-600">
                  Get detailed analytics and winning strategies
                </p>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>
    </div>
  );
}
