import { useState, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { modelenceQuery, modelenceMutation, createQueryKey } from '@modelence/react-query';
import { Sidebar } from '@/client/components/Sidebar';
import { OpportunityCard } from '@/client/components/OpportunityCard';
import { Button } from '@/client/components/ui/Button';
import { Input } from '@/client/components/ui/Input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/client/components/ui/Dialog';
import { Search, Filter, X } from 'lucide-react';
import LoadingSpinner from '@/client/components/LoadingSpinner';
import toast from 'react-hot-toast';

interface Opportunity {
  _id: string;
  title: string;
  description: string;
  category: string;
  region: string;
  reward: number;
  deadline: Date;
  urgency: string;
  imageUrl?: string;
  applicationUrl?: string;
}

interface Filters {
  [key: string]: string | number | undefined;
  category?: string;
  region?: string;
  urgency?: string;
  minReward?: number;
  maxReward?: number;
  search?: string;
}

export default function ExplorePage() {
  const queryClient = useQueryClient();
  const [filters, setFilters] = useState<Filters>({});
  const [searchInput, setSearchInput] = useState('');
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [tempFilters, setTempFilters] = useState<Filters>({});

  const { data: opportunities, isLoading } = useQuery({
    ...modelenceQuery<Opportunity[]>('grantradar.getOpportunities', filters),
  });

  const { data: categories } = useQuery({
    ...modelenceQuery<string[]>('grantradar.getCategories', {}),
  });

  const { data: regions } = useQuery({
    ...modelenceQuery<string[]>('grantradar.getRegions', {}),
  });

  const { mutate: saveOpportunity } = useMutation({
    ...modelenceMutation('grantradar.saveOpportunity'),
    onSuccess: () => {
      toast.success('Opportunity saved!');
      queryClient.invalidateQueries({ queryKey: createQueryKey('grantradar.getOpportunityStatus', {}) });
      queryClient.invalidateQueries({ queryKey: createQueryKey('grantradar.getSavedOpportunities', {}) });
    },
    onError: (error: Error) => {
      toast.error(error.message);
    },
  });

  const { mutate: applyToOpportunity } = useMutation({
    ...modelenceMutation('grantradar.applyToOpportunity'),
    onSuccess: () => {
      toast.success('Application submitted!');
      queryClient.invalidateQueries({ queryKey: createQueryKey('grantradar.getOpportunityStatus', {}) });
      queryClient.invalidateQueries({ queryKey: createQueryKey('grantradar.getAppliedOpportunities', {}) });
    },
    onError: (error: Error) => {
      toast.error(error.message);
    },
  });

  const handleSearch = useCallback(() => {
    setFilters({ ...filters, search: searchInput });
  }, [searchInput, filters]);

  const handleApplyFilters = useCallback(() => {
    setFilters(tempFilters);
    setIsFilterOpen(false);
  }, [tempFilters]);

  const handleClearFilters = useCallback(() => {
    setFilters({});
    setTempFilters({});
    setSearchInput('');
  }, []);

  const activeFilterCount = Object.keys(filters).filter(
    (key) => key !== 'search' && filters[key as keyof Filters]
  ).length;

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />

      <main className="flex-1 ml-64">
        <div className="border-b border-gray-200 bg-white sticky top-0 z-10">
          <div className="max-w-7xl mx-auto px-6 py-4">
            <div className="flex items-center gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  placeholder="Search opportunities..."
                  value={searchInput}
                  onChange={(e) => setSearchInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                  className="pl-10 pr-4"
                />
              </div>

              <Dialog open={isFilterOpen} onOpenChange={setIsFilterOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="relative">
                    <Filter className="w-4 h-4 mr-2" />
                    Filters
                    {activeFilterCount > 0 && (
                      <span className="ml-2 px-2 py-0.5 text-xs bg-indigo-600 text-white rounded-full">
                        {activeFilterCount}
                      </span>
                    )}
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Filter Opportunities</DialogTitle>
                  </DialogHeader>

                  <div className="space-y-4 py-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Category</label>
                      <select
                        value={tempFilters.category || ''}
                        onChange={(e) =>
                          setTempFilters({ ...tempFilters, category: e.target.value || undefined })
                        }
                        className="w-full px-3 py-2 border border-gray-300 rounded-md"
                      >
                        <option value="">All Categories</option>
                        {categories?.map((cat) => (
                          <option key={cat} value={cat}>
                            {cat}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Region</label>
                      <select
                        value={tempFilters.region || ''}
                        onChange={(e) =>
                          setTempFilters({ ...tempFilters, region: e.target.value || undefined })
                        }
                        className="w-full px-3 py-2 border border-gray-300 rounded-md"
                      >
                        <option value="">All Regions</option>
                        {regions?.map((reg) => (
                          <option key={reg} value={reg}>
                            {reg}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Urgency</label>
                      <select
                        value={tempFilters.urgency || ''}
                        onChange={(e) =>
                          setTempFilters({ ...tempFilters, urgency: e.target.value || undefined })
                        }
                        className="w-full px-3 py-2 border border-gray-300 rounded-md"
                      >
                        <option value="">All Urgencies</option>
                        <option value="safe">Safe</option>
                        <option value="approaching">Approaching</option>
                        <option value="closing-soon">Closing Soon</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Reward Range</label>
                      <div className="flex gap-2">
                        <Input
                          type="number"
                          placeholder="Min"
                          value={tempFilters.minReward || ''}
                          onChange={(e) =>
                            setTempFilters({
                              ...tempFilters,
                              minReward: e.target.value ? Number(e.target.value) : undefined,
                            })
                          }
                        />
                        <Input
                          type="number"
                          placeholder="Max"
                          value={tempFilters.maxReward || ''}
                          onChange={(e) =>
                            setTempFilters({
                              ...tempFilters,
                              maxReward: e.target.value ? Number(e.target.value) : undefined,
                            })
                          }
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      onClick={() => {
                        setTempFilters({});
                        handleClearFilters();
                      }}
                      className="flex-1"
                    >
                      Clear All
                    </Button>
                    <Button onClick={handleApplyFilters} className="flex-1 bg-indigo-600 hover:bg-indigo-700">
                      Apply Filters
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>

              {activeFilterCount > 0 && (
                <Button variant="ghost" size="sm" onClick={handleClearFilters}>
                  <X className="w-4 h-4" />
                </Button>
              )}
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-6 py-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-8">Explore Opportunities</h1>

          {isLoading ? (
            <div className="flex justify-center items-center py-20">
              <LoadingSpinner />
            </div>
          ) : opportunities && opportunities.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {opportunities.map((opportunity) => (
                <OpportunityCard
                  key={opportunity._id}
                  title={opportunity.title}
                  description={opportunity.description}
                  category={opportunity.category}
                  region={opportunity.region}
                  reward={opportunity.reward}
                  deadline={opportunity.deadline}
                  urgency={opportunity.urgency}
                  imageUrl={opportunity.imageUrl}
                  onSave={() => saveOpportunity({ opportunityId: opportunity._id })}
                  onApply={() => applyToOpportunity({ opportunityId: opportunity._id })}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-20">
              <p className="text-gray-500 text-lg">No opportunities found</p>
              <p className="text-gray-400 text-sm mt-2">Try adjusting your filters</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
