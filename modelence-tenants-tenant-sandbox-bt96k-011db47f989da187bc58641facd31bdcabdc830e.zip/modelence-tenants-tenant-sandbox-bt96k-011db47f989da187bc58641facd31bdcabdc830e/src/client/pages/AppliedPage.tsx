import { useQuery } from '@tanstack/react-query';
import { modelenceQuery } from '@modelence/react-query';
import { Sidebar } from '@/client/components/Sidebar';
import { OpportunityCard } from '@/client/components/OpportunityCard';
import LoadingSpinner from '@/client/components/LoadingSpinner';

interface AppliedOpportunity {
  _id: string;
  title: string;
  description: string;
  category: string;
  region: string;
  reward: number;
  deadline: Date;
  urgency: string;
  imageUrl?: string;
  applicationUrl?: string;
  appliedAt?: Date;
  status?: string;
}

export default function AppliedPage() {
  const { data: appliedOpportunities, isLoading } = useQuery({
    ...modelenceQuery<AppliedOpportunity[]>('grantradar.getAppliedOpportunities', {}),
  });

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />

      <main className="flex-1 ml-64">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-8">Applied Opportunities</h1>

          {isLoading ? (
            <div className="flex justify-center items-center py-20">
              <LoadingSpinner />
            </div>
          ) : appliedOpportunities && appliedOpportunities.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {appliedOpportunities.map((opportunity) => (
                <OpportunityCard
                  key={opportunity._id}
                  title={opportunity.title}
                  description={opportunity.description}
                  category={opportunity.category}
                  region={opportunity.region}
                  reward={opportunity.reward}
                  deadline={opportunity.deadline}
                  urgency={opportunity.urgency}
                  imageUrl={opportunity.imageUrl}
                  isApplied={true}
                  onSave={() => {}}
                  onApply={() => {}}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-20">
              <p className="text-gray-500 text-lg">No applications yet</p>
              <p className="text-gray-400 text-sm mt-2">
                Start applying to opportunities to see them here
              </p>
              <a
                href="/explore"
                className="inline-block mt-6 px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-all"
              >
                Explore Opportunities
              </a>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
