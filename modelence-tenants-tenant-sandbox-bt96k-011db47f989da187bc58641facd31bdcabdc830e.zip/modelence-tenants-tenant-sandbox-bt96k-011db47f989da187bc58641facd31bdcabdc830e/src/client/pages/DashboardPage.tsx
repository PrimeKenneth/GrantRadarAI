import { useQuery } from '@tanstack/react-query';
import { modelenceQuery } from '@modelence/react-query';
import { Sidebar } from '@/client/components/Sidebar';
import { Card, CardContent, CardHeader, CardTitle } from '@/client/components/ui/Card';
import { Bookmark, CheckCircle, DollarSign, Clock } from 'lucide-react';
import LoadingSpinner from '@/client/components/LoadingSpinner';

interface DashboardStats {
  savedCount: number;
  appliedCount: number;
  totalRewardValue: number;
  upcomingDeadlines: number;
}

export default function DashboardPage() {
  const { data: stats, isLoading } = useQuery({
    ...modelenceQuery<DashboardStats>('grantradar.getDashboardStats', {}),
  });

  if (isLoading) {
    return (
      <div className="flex min-h-screen bg-gray-50">
        <Sidebar />
        <main className="flex-1 ml-64 flex items-center justify-center">
          <LoadingSpinner />
        </main>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />

      <main className="flex-1 ml-64">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Dashboard</h1>
            <p className="text-gray-600">Welcome back! Here's your opportunity overview.</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="border-l-4 border-l-indigo-600">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Saved Opportunities</CardTitle>
                <Bookmark className="w-5 h-5 text-indigo-600" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-gray-900">{stats?.savedCount || 0}</div>
                <p className="text-xs text-gray-500 mt-1">Opportunities bookmarked</p>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-green-600">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Applied</CardTitle>
                <CheckCircle className="w-5 h-5 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-gray-900">{stats?.appliedCount || 0}</div>
                <p className="text-xs text-gray-500 mt-1">Applications submitted</p>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-purple-600">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Total Potential Value</CardTitle>
                <DollarSign className="w-5 h-5 text-purple-600" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-gray-900">
                  ${(stats?.totalRewardValue || 0).toLocaleString()}
                </div>
                <p className="text-xs text-gray-500 mt-1">From saved opportunities</p>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-orange-600">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Upcoming Deadlines</CardTitle>
                <Clock className="w-5 h-5 text-orange-600" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-gray-900">{stats?.upcomingDeadlines || 0}</div>
                <p className="text-xs text-gray-500 mt-1">Within 7 days</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <a
                  href="/explore"
                  className="flex items-center justify-between p-4 rounded-lg bg-gradient-to-r from-indigo-50 to-purple-50 hover:from-indigo-100 hover:to-purple-100 transition-all"
                >
                  <div>
                    <p className="font-semibold text-gray-900">Explore Opportunities</p>
                    <p className="text-sm text-gray-600">Discover new grants</p>
                  </div>
                  <span className="text-indigo-600">→</span>
                </a>

                <a
                  href="/saved"
                  className="flex items-center justify-between p-4 rounded-lg bg-gradient-to-r from-green-50 to-emerald-50 hover:from-green-100 hover:to-emerald-100 transition-all"
                >
                  <div>
                    <p className="font-semibold text-gray-900">View Saved</p>
                    <p className="text-sm text-gray-600">Review your bookmarks</p>
                  </div>
                  <span className="text-green-600">→</span>
                </a>

                <a
                  href="/applied"
                  className="flex items-center justify-between p-4 rounded-lg bg-gradient-to-r from-blue-50 to-cyan-50 hover:from-blue-100 hover:to-cyan-100 transition-all"
                >
                  <div>
                    <p className="font-semibold text-gray-900">Track Applications</p>
                    <p className="text-sm text-gray-600">Monitor your progress</p>
                  </div>
                  <span className="text-blue-600">→</span>
                </a>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Tips & Insights</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 rounded-lg bg-blue-50 border border-blue-200">
                  <p className="text-sm font-semibold text-blue-900 mb-1">Stay on Top of Deadlines</p>
                  <p className="text-xs text-blue-700">
                    Check your saved opportunities regularly and set reminders for approaching deadlines.
                  </p>
                </div>

                <div className="p-4 rounded-lg bg-purple-50 border border-purple-200">
                  <p className="text-sm font-semibold text-purple-900 mb-1">Diversify Your Applications</p>
                  <p className="text-xs text-purple-700">
                    Apply to opportunities across different categories to increase your chances of success.
                  </p>
                </div>

                <div className="p-4 rounded-lg bg-green-50 border border-green-200">
                  <p className="text-sm font-semibold text-green-900 mb-1">Prepare Early</p>
                  <p className="text-xs text-green-700">
                    Start gathering required documents and information before the deadline approaches.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
