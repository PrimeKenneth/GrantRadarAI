import { dbOpportunities } from '@/server/grantradar/db';

export async function createSampleOpportunities() {
  const existingCount = await dbOpportunities.fetch({});

  // Only create sample data if there are no opportunities yet
  if (existingCount.length > 0) {
    console.log('Sample opportunities already exist, skipping...');
    return;
  }

  const sampleOpportunities = [
    {
      title: 'Tech Innovation Grant 2025',
      description:
        'Funding for innovative technology startups working on AI, machine learning, and blockchain solutions. Support for early-stage companies with high growth potential.',
      category: 'Technology',
      region: 'North America',
      reward: 50000,
      deadline: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
      urgency: 'safe',
      imageUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800',
      applicationUrl: 'https://example.com/apply/tech-innovation',
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      title: 'Environmental Sustainability Fund',
      description:
        'Supporting projects focused on renewable energy, waste reduction, and environmental conservation. Open to non-profits and social enterprises.',
      category: 'Environment',
      region: 'Europe',
      reward: 75000,
      deadline: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000), // 15 days from now
      urgency: 'safe',
      imageUrl: 'https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?w=800',
      applicationUrl: 'https://example.com/apply/environmental',
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      title: 'Small Business Recovery Grant',
      description:
        'Financial assistance for small businesses impacted by economic challenges. Covers operational costs, employee wages, and digital transformation.',
      category: 'Business',
      region: 'Global',
      reward: 25000,
      deadline: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000), // 5 days from now
      urgency: 'approaching',
      imageUrl: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=800',
      applicationUrl: 'https://example.com/apply/small-business',
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      title: 'Arts & Culture Development Fund',
      description:
        'Supporting artists, musicians, and cultural organizations. Funding for exhibitions, performances, and community arts programs.',
      category: 'Arts & Culture',
      region: 'Asia',
      reward: 30000,
      deadline: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000), // 45 days from now
      urgency: 'safe',
      imageUrl: 'https://images.unsplash.com/photo-1460661419201-fd4cecdf8a8b?w=800',
      applicationUrl: 'https://example.com/apply/arts-culture',
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      title: 'Healthcare Innovation Challenge',
      description:
        'Grant for healthcare startups developing telemedicine, medical devices, and patient care solutions. Focus on improving healthcare accessibility.',
      category: 'Healthcare',
      region: 'North America',
      reward: 100000,
      deadline: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000), // 2 days from now
      urgency: 'closing-soon',
      imageUrl: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800',
      applicationUrl: 'https://example.com/apply/healthcare',
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      title: 'Education Technology Grant',
      description:
        'Funding for EdTech solutions that improve learning outcomes. Supporting platforms for remote learning, student engagement, and teacher tools.',
      category: 'Education',
      region: 'Global',
      reward: 60000,
      deadline: new Date(Date.now() + 20 * 24 * 60 * 60 * 1000), // 20 days from now
      urgency: 'safe',
      imageUrl: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=800',
      applicationUrl: 'https://example.com/apply/edtech',
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      title: 'Rural Development Initiative',
      description:
        'Supporting projects that improve infrastructure, connectivity, and economic opportunities in rural communities. Open to social enterprises.',
      category: 'Community Development',
      region: 'Africa',
      reward: 40000,
      deadline: new Date(Date.now() + 8 * 24 * 60 * 60 * 1000), // 8 days from now
      urgency: 'safe',
      imageUrl: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?w=800',
      applicationUrl: 'https://example.com/apply/rural-development',
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      title: 'Women Entrepreneurs Fund',
      description:
        'Dedicated funding for women-led startups and businesses. Focus on empowering female entrepreneurs across all industries.',
      category: 'Business',
      region: 'Global',
      reward: 35000,
      deadline: new Date(Date.now() + 12 * 24 * 60 * 60 * 1000), // 12 days from now
      urgency: 'safe',
      imageUrl: 'https://images.unsplash.com/photo-1573164713714-d95e436ab8d6?w=800',
      applicationUrl: 'https://example.com/apply/women-entrepreneurs',
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  ];

  await dbOpportunities.insertMany(sampleOpportunities);
  console.log(`Created ${sampleOpportunities.length} sample opportunities`);
}
