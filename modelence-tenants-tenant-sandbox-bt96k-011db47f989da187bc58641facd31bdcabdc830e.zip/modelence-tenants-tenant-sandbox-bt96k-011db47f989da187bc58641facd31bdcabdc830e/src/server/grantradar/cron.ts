import { time } from 'modelence';
import { dbOpportunities } from './db';

export const updateUrgencyCron = {
  description: 'Update deadline urgency status for all opportunities',
  interval: time.hours(1), // Run every hour
  handler: async () => {
    const now = new Date();
    const opportunities = await dbOpportunities.fetch({});

    for (const opportunity of opportunities) {
      const daysUntilDeadline = Math.ceil(
        (opportunity.deadline.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)
      );

      let urgency: string;
      if (daysUntilDeadline <= 3) {
        urgency = 'closing-soon';
      } else if (daysUntilDeadline <= 7) {
        urgency = 'approaching';
      } else {
        urgency = 'safe';
      }

      if (opportunity.urgency !== urgency) {
        await dbOpportunities.updateOne(
          { _id: opportunity._id },
          { $set: { urgency, updatedAt: new Date() } }
        );
      }
    }
  },
};
