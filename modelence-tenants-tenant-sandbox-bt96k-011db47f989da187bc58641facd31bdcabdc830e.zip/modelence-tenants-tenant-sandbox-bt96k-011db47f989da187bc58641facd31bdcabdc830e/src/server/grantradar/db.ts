import { Store, schema } from 'modelence/server';

export const dbOpportunities = new Store('opportunities', {
  schema: {
    title: schema.string(),
    description: schema.string(),
    category: schema.string(),
    region: schema.string(),
    reward: schema.number(),
    deadline: schema.date(),
    urgency: schema.string(), // 'safe', 'approaching', 'closing-soon'
    imageUrl: schema.string().optional(),
    applicationUrl: schema.string().optional(),
    createdAt: schema.date(),
    updatedAt: schema.date(),
  },
  indexes: [
    { key: { category: 1 } },
    { key: { region: 1 } },
    { key: { deadline: 1 } },
    { key: { urgency: 1 } },
    { key: { createdAt: -1 } },
  ],
});

export const dbSavedOpportunities = new Store('savedOpportunities', {
  schema: {
    userId: schema.userId(),
    opportunityId: schema.objectId(),
    savedAt: schema.date(),
  },
  indexes: [
    { key: { userId: 1, opportunityId: 1 }, unique: true },
    { key: { userId: 1 } },
    { key: { opportunityId: 1 } },
  ],
});

export const dbAppliedOpportunities = new Store('appliedOpportunities', {
  schema: {
    userId: schema.userId(),
    opportunityId: schema.objectId(),
    appliedAt: schema.date(),
    status: schema.string(), // 'applied', 'in-review', 'accepted', 'rejected'
  },
  indexes: [
    { key: { userId: 1, opportunityId: 1 }, unique: true },
    { key: { userId: 1 } },
    { key: { opportunityId: 1 } },
  ],
});
