import z from 'zod';
import { AuthError } from 'modelence';
import { Module, ObjectId, UserInfo } from 'modelence/server';
import { dbOpportunities, dbSavedOpportunities, dbAppliedOpportunities } from './db';
import { updateUrgencyCron } from './cron';

// Helper function to calculate urgency
function calculateUrgency(deadline: Date): string {
  const now = new Date();
  const daysUntilDeadline = Math.ceil(
    (deadline.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)
  );

  if (daysUntilDeadline <= 3) {
    return 'closing-soon';
  } else if (daysUntilDeadline <= 7) {
    return 'approaching';
  } else {
    return 'safe';
  }
}

export default new Module('grantradar', {
  stores: [dbOpportunities, dbSavedOpportunities, dbAppliedOpportunities],

  queries: {
    // Get all opportunities with optional filters
    getOpportunities: async (args: unknown) => {
      const filters = z
        .object({
          category: z.string().optional(),
          region: z.string().optional(),
          urgency: z.string().optional(),
          minReward: z.number().optional(),
          maxReward: z.number().optional(),
          search: z.string().optional(),
        })
        .parse(args);

      const query: any = {};

      if (filters.category) {
        query.category = filters.category;
      }

      if (filters.region) {
        query.region = filters.region;
      }

      if (filters.urgency) {
        query.urgency = filters.urgency;
      }

      if (filters.minReward !== undefined || filters.maxReward !== undefined) {
        query.reward = {};
        if (filters.minReward !== undefined) {
          query.reward.$gte = filters.minReward;
        }
        if (filters.maxReward !== undefined) {
          query.reward.$lte = filters.maxReward;
        }
      }

      if (filters.search) {
        query.$or = [
          { title: { $regex: filters.search, $options: 'i' } },
          { description: { $regex: filters.search, $options: 'i' } },
        ];
      }

      const opportunities = await dbOpportunities.fetch(query, {
        sort: { createdAt: -1 },
        limit: 100,
      });

      return opportunities.map((opp) => ({
        _id: opp._id.toString(),
        title: opp.title,
        description: opp.description,
        category: opp.category,
        region: opp.region,
        reward: opp.reward,
        deadline: opp.deadline,
        urgency: opp.urgency,
        imageUrl: opp.imageUrl,
        applicationUrl: opp.applicationUrl,
        createdAt: opp.createdAt,
      }));
    },

    // Get single opportunity
    getOpportunity: async (args: unknown) => {
      const { id } = z.object({ id: z.string() }).parse(args);
      const opportunity = await dbOpportunities.requireOne({ _id: new ObjectId(id) });

      return {
        _id: opportunity._id.toString(),
        title: opportunity.title,
        description: opportunity.description,
        category: opportunity.category,
        region: opportunity.region,
        reward: opportunity.reward,
        deadline: opportunity.deadline,
        urgency: opportunity.urgency,
        imageUrl: opportunity.imageUrl,
        applicationUrl: opportunity.applicationUrl,
        createdAt: opportunity.createdAt,
      };
    },

    // Get user's saved opportunities
    getSavedOpportunities: async (_args: unknown, { user }: { user: UserInfo | null }) => {
      if (!user) {
        throw new AuthError('Not authenticated');
      }

      const saved = await dbSavedOpportunities.fetch({ userId: new ObjectId(user.id) });
      const opportunityIds = saved.map((s) => s.opportunityId);

      if (opportunityIds.length === 0) {
        return [];
      }

      const opportunities = await dbOpportunities.fetch({ _id: { $in: opportunityIds } });

      return opportunities.map((opp) => ({
        _id: opp._id.toString(),
        title: opp.title,
        description: opp.description,
        category: opp.category,
        region: opp.region,
        reward: opp.reward,
        deadline: opp.deadline,
        urgency: opp.urgency,
        imageUrl: opp.imageUrl,
        applicationUrl: opp.applicationUrl,
        savedAt: saved.find((s) => s.opportunityId.equals(opp._id))?.savedAt,
      }));
    },

    // Get user's applied opportunities
    getAppliedOpportunities: async (_args: unknown, { user }: { user: UserInfo | null }) => {
      if (!user) {
        throw new AuthError('Not authenticated');
      }

      const applied = await dbAppliedOpportunities.fetch({ userId: new ObjectId(user.id) });
      const opportunityIds = applied.map((a) => a.opportunityId);

      if (opportunityIds.length === 0) {
        return [];
      }

      const opportunities = await dbOpportunities.fetch({ _id: { $in: opportunityIds } });

      return opportunities.map((opp) => {
        const appliedRecord = applied.find((a) => a.opportunityId.equals(opp._id));
        return {
          _id: opp._id.toString(),
          title: opp.title,
          description: opp.description,
          category: opp.category,
          region: opp.region,
          reward: opp.reward,
          deadline: opp.deadline,
          urgency: opp.urgency,
          imageUrl: opp.imageUrl,
          applicationUrl: opp.applicationUrl,
          appliedAt: appliedRecord?.appliedAt,
          status: appliedRecord?.status,
        };
      });
    },

    // Get user dashboard stats
    getDashboardStats: async (_args: unknown, { user }: { user: UserInfo | null }) => {
      if (!user) {
        throw new AuthError('Not authenticated');
      }

      const saved = await dbSavedOpportunities.fetch({ userId: new ObjectId(user.id) });
      const applied = await dbAppliedOpportunities.fetch({ userId: new ObjectId(user.id) });

      const savedOpportunityIds = saved.map((s) => s.opportunityId);

      let totalRewardValue = 0;
      if (savedOpportunityIds.length > 0) {
        const savedOpportunities = await dbOpportunities.fetch({
          _id: { $in: savedOpportunityIds },
        });
        totalRewardValue = savedOpportunities.reduce((sum, opp) => sum + opp.reward, 0);
      }

      // Get upcoming deadlines (next 7 days)
      const sevenDaysFromNow = new Date();
      sevenDaysFromNow.setDate(sevenDaysFromNow.getDate() + 7);

      let upcomingDeadlines = 0;
      if (savedOpportunityIds.length > 0) {
        const upcomingOpps = await dbOpportunities.fetch({
          _id: { $in: savedOpportunityIds },
          deadline: { $lte: sevenDaysFromNow },
        });
        upcomingDeadlines = upcomingOpps.length;
      }

      return {
        savedCount: saved.length,
        appliedCount: applied.length,
        totalRewardValue,
        upcomingDeadlines,
      };
    },

    // Check if user saved/applied to an opportunity
    getOpportunityStatus: async (args: unknown, { user }: { user: UserInfo | null }) => {
      if (!user) {
        return { isSaved: false, isApplied: false };
      }

      const { opportunityId } = z.object({ opportunityId: z.string() }).parse(args);

      const saved = await dbSavedOpportunities.findOne({
        userId: new ObjectId(user.id),
        opportunityId: new ObjectId(opportunityId),
      });

      const applied = await dbAppliedOpportunities.findOne({
        userId: new ObjectId(user.id),
        opportunityId: new ObjectId(opportunityId),
      });

      return {
        isSaved: !!saved,
        isApplied: !!applied,
      };
    },

    // Get all categories (for filter dropdown)
    getCategories: async () => {
      const opportunities = await dbOpportunities.fetch({});
      const categories = [...new Set(opportunities.map((opp) => opp.category))];
      return categories.sort();
    },

    // Get all regions (for filter dropdown)
    getRegions: async () => {
      const opportunities = await dbOpportunities.fetch({});
      const regions = [...new Set(opportunities.map((opp) => opp.region))];
      return regions.sort();
    },
  },

  mutations: {
    // Save an opportunity
    saveOpportunity: async (args: unknown, { user }: { user: UserInfo | null }) => {
      if (!user) {
        throw new AuthError('Not authenticated');
      }

      const { opportunityId } = z.object({ opportunityId: z.string() }).parse(args);

      // Check if already saved
      const existing = await dbSavedOpportunities.findOne({
        userId: new ObjectId(user.id),
        opportunityId: new ObjectId(opportunityId),
      });

      if (existing) {
        throw new Error('Opportunity already saved');
      }

      await dbSavedOpportunities.insertOne({
        userId: new ObjectId(user.id),
        opportunityId: new ObjectId(opportunityId),
        savedAt: new Date(),
      });
    },

    // Unsave an opportunity
    unsaveOpportunity: async (args: unknown, { user }: { user: UserInfo | null }) => {
      if (!user) {
        throw new AuthError('Not authenticated');
      }

      const { opportunityId } = z.object({ opportunityId: z.string() }).parse(args);

      const { deletedCount } = await dbSavedOpportunities.deleteOne({
        userId: new ObjectId(user.id),
        opportunityId: new ObjectId(opportunityId),
      });

      if (deletedCount === 0) {
        throw new Error('Opportunity not found in saved list');
      }
    },

    // Apply to an opportunity
    applyToOpportunity: async (args: unknown, { user }: { user: UserInfo | null }) => {
      if (!user) {
        throw new AuthError('Not authenticated');
      }

      const { opportunityId } = z.object({ opportunityId: z.string() }).parse(args);

      // Check if already applied
      const existing = await dbAppliedOpportunities.findOne({
        userId: new ObjectId(user.id),
        opportunityId: new ObjectId(opportunityId),
      });

      if (existing) {
        throw new Error('Already applied to this opportunity');
      }

      await dbAppliedOpportunities.insertOne({
        userId: new ObjectId(user.id),
        opportunityId: new ObjectId(opportunityId),
        appliedAt: new Date(),
        status: 'applied',
      });
    },

    // Admin: Create opportunity
    createOpportunity: async (args: unknown, { user }: { user: UserInfo | null }) => {
      if (!user) {
        throw new AuthError('Not authenticated');
      }

      // TODO: Add admin role check when user roles are implemented
      // For now, any authenticated user can create opportunities

      const data = z
        .object({
          title: z.string().min(1),
          description: z.string().min(1),
          category: z.string().min(1),
          region: z.string().min(1),
          reward: z.number().min(0),
          deadline: z.string().transform((str) => new Date(str)),
          imageUrl: z.string().optional(),
          applicationUrl: z.string().optional(),
        })
        .parse(args);

      const urgency = calculateUrgency(data.deadline);

      await dbOpportunities.insertOne({
        ...data,
        urgency,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
    },

    // Admin: Update opportunity
    updateOpportunity: async (args: unknown, { user }: { user: UserInfo | null }) => {
      if (!user) {
        throw new AuthError('Not authenticated');
      }

      const { id, ...data } = z
        .object({
          id: z.string(),
          title: z.string().min(1).optional(),
          description: z.string().min(1).optional(),
          category: z.string().min(1).optional(),
          region: z.string().min(1).optional(),
          reward: z.number().min(0).optional(),
          deadline: z.string().transform((str) => new Date(str)).optional(),
          imageUrl: z.string().optional(),
          applicationUrl: z.string().optional(),
        })
        .parse(args);

      const updateData: any = { ...data, updatedAt: new Date() };

      // Recalculate urgency if deadline changed
      if (data.deadline) {
        updateData.urgency = calculateUrgency(data.deadline);
      }

      const { modifiedCount } = await dbOpportunities.updateOne(
        { _id: new ObjectId(id) },
        { $set: updateData }
      );

      if (modifiedCount === 0) {
        throw new Error('Opportunity not found');
      }
    },

    // Admin: Delete opportunity
    deleteOpportunity: async (args: unknown, { user }: { user: UserInfo | null }) => {
      if (!user) {
        throw new AuthError('Not authenticated');
      }

      const { id } = z.object({ id: z.string() }).parse(args);

      // Delete the opportunity
      const { deletedCount } = await dbOpportunities.deleteOne({ _id: new ObjectId(id) });

      if (deletedCount === 0) {
        throw new Error('Opportunity not found');
      }

      // Also delete all saved and applied records for this opportunity
      await dbSavedOpportunities.deleteMany({ opportunityId: new ObjectId(id) });
      await dbAppliedOpportunities.deleteMany({ opportunityId: new ObjectId(id) });
    },
  },

  cronJobs: {
    updateUrgency: updateUrgencyCron,
  },
});
