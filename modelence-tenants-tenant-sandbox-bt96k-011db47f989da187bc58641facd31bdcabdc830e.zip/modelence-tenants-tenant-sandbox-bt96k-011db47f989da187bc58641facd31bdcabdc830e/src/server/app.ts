import { startApp } from 'modelence/server';
import exampleModule from '@/server/example';
import grantradarModule from '@/server/grantradar';
import { createDemoUser } from '@/server/migrations/createDemoUser';
import { createSampleOpportunities } from '@/server/migrations/createSampleOpportunities';

startApp({
  modules: [exampleModule, grantradarModule],

  migrations: [
    {
      version: 1,
      description: 'Create demo user',
      handler: createDemoUser,
    },
    {
      version: 2,
      description: 'Create sample opportunities',
      handler: createSampleOpportunities,
    },
  ],
});
