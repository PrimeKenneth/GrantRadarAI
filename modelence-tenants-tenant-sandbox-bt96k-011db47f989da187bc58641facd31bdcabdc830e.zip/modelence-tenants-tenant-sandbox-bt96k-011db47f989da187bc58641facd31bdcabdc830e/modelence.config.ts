const modelenceConfig = {
  serverDir: './src/server',
  serverEntry: 'app.ts'
};

export default modelenceConfig;
